# start

npm i
or
if above don't work then use --> npm i --force

then npm start to start the server

In the above blog post app we can

Add new post
delete post
edit post

we are storing the posts data in local storage.

## hosted link

https://bytelearn-7491b.web.app/

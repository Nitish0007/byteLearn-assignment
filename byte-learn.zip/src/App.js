import "./App.css";

import MainPage from "./pages/MainPage/MainPage";

function App() {
  return (
    <div className="App">
      <MainPage path="/" />
    </div>
  );
}

export default App;
